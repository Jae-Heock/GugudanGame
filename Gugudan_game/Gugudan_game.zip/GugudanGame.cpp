#include <iostream>
#include <stdio.h>
#include "GugudanGame.h"

int main()
{
	GugudanGame gugudangame;
	gugudangame.GameRoop();

	return 0;
}